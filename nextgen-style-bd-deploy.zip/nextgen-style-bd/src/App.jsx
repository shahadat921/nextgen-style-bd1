import { useState, useEffect, useRef } from "react";

const ADMIN_PASS = "nextgen2026";

// CORS proxy — ব্রাউজার থেকে m3u8 চালানোর জন্য দরকার
const PROXY = "https://corsproxy.io/?url=";
const proxify = (url) => {
  if (!url) return url;
  if (url.includes("gpcdn.net") || url.includes("zohanayaan.com") ||
      url.includes("aynaott.com") || url.includes("pishow.tv")) {
    return PROXY + encodeURIComponent(url);
  }
  return url;
};

const DEFAULT_CHANNELS = [
  {id:1,  name:"Sports Legends",    nameBn:"স্পোর্টস লেজেন্ডস",      logo:"https://tstatic.akash-go.com/cms-ui/images/custom-content/1770377900139.png",  color:"#e63946", url:"https://nomawnoijl.gpcdn.net/akash/sportslegends/playlist.m3u8"},
  {id:2,  name:"Flash Guys HD",     nameBn:"ফ্ল্যাশ গাইস এইচডি",      logo:"https://tstatic.akash-go.com/cms-ui/images/custom-content/1770378074527.png",  color:"#ff9800", url:"https://nomawnoijl.gpcdn.net/akash/flashguys/playlist.m3u8"},
  {id:3,  name:"Sports Range",      nameBn:"স্পোর্টস রেঞ্জ",           logo:"https://tstatic.akash-go.com/cms-ui/images/custom-content/1770380601958.png",  color:"#4caf50", url:"https://nomawnoijl.gpcdn.net/akash/sportrange/playlist.m3u8"},
  {id:4,  name:"Thunder Er",        nameBn:"থান্ডার",                   logo:"https://tstatic.akash-go.com/cms-ui/images/custom-content/1770380791303.png",  color:"#9c27b0", url:"https://nomawnoijl.gpcdn.net/akash/thunder/playlist.m3u8"},
  {id:5,  name:"Fighters",          nameBn:"ফাইটার্স",                  logo:"https://tstatic.akash-go.com/cms-ui/images/custom-content/1770380942670.png",  color:"#f44336", url:"https://nomawnoijl.gpcdn.net/akash/fighter/playlist.m3u8"},
  {id:6,  name:"Crazy Ex",          nameBn:"ক্রেজি এক্স",               logo:"https://tstatic.akash-go.com/cms-ui/images/custom-content/1778085745609.png",  color:"#e91e63", url:"https://nomawnoijl.gpcdn.net/akash/crazy_ex/playlist.m3u8"},
  {id:7,  name:"Star Sports 1",     nameBn:"স্টার স্পোর্টস ১",         logo:"https://abusaeeidx.github.io/Tv-Channel-Logo/CricHD/runded/16-by-xfireflix.png",color:"#2196f3", url:"https://cdn8.zohanayaan.com:1686/hls/star1in.m3u8?md5=o9P8WJ_RKHQ8MPqiysji3Q&expires=1780663217"},
  {id:8,  name:"PTV Sports",        nameBn:"পিটিভি স্পোর্টস",          logo:"https://abusaeeidx.github.io/Tv-Channel-Logo/CricHD/runded/20-by-xfireflix.png",color:"#009688", url:"https://cdn6.zohanayaan.com:1686/hls/ptvpk.m3u8?md5=ydVLs9QlWy0nEchqNnRlzQ&expires=1780663218"},
  {id:9,  name:"Willow HD",         nameBn:"উইলো এইচডি",               logo:"https://abusaeeidx.github.io/Tv-Channel-Logo/CricHD/runded/38-by-xfireflix.png",color:"#8bc34a", url:"https://cdn2.zohanayaan.com:1686/hls/willowusa.m3u8?md5=1W5GmrRPEhQOJcVK8KHEKQ&expires=1780663218"},
  {id:10, name:"Ten Sports",        nameBn:"টেন স্পোর্টস",             logo:"https://abusaeeidx.github.io/Tv-Channel-Logo/CricHD/runded/10-by-xfireflix.png",color:"#ff5722", url:"https://cdn10.zohanayaan.com:1686/hls/tenspk.m3u8?md5=6BI_mV-_FZxWDQviUZSf9Q&expires=1780663218"},
  {id:11, name:"A Sports HD",       nameBn:"এ স্পোর্টস এইচডি",        logo:"https://abusaeeidx.github.io/Tv-Channel-Logo/CricHD/runded/12-by-xfireflix.png",color:"#673ab7", url:"https://cdn4.zohanayaan.com:1686/hls/asportshd.m3u8?md5=eqNjW0UhvKm8dyizjo3eFg&expires=1780663218"},
  {id:12, name:"Sky Sports Cricket",nameBn:"স্কাই স্পোর্টস ক্রিকেট",  logo:"https://abusaeeidx.github.io/Tv-Channel-Logo/CricHD/runded/9-by-xfireflix.png", color:"#00bcd4", url:"https://cdn5.zohanayaan.com:1686/hls/skyscric.m3u8?md5=ZNA-0cz7I96Hpz5QOq64jQ&expires=1780663218"},
  {id:13, name:"Fox Cricket 501",   nameBn:"ফক্স ক্রিকেট ৫০১",        logo:"https://abusaeeidx.github.io/Tv-Channel-Logo/CricHD/runded/6-by-xfireflix.png", color:"#795548", url:"https://cdn9.zohanayaan.com:1686/hls/fox501.m3u8?md5=GIVLwiHMp94XcXUXk8iCJA&expires=1780663222"},
  {id:14, name:"T Sports HD",       nameBn:"টি স্পোর্টস এইচডি",       logo:"https://s3.aynaott.com/storage/dbc585f70a60b9855b6e13a8ce4cb6f4",              color:"#e53935", url:"https://tvsen7.aynaott.com/tsports-hd/index.m3u8?e=1780662761&u=78be6644-0a65-48ec-81a4-089ac65a2619&token=755de1abb34402b6543ac8e82a34488d"},
  {id:15, name:"PTV Sports (Ayna)", nameBn:"পিটিভি (আয়না)",           logo:"https://s3.aynaott.com/storage/9d9d7cbfba5a8ceea648bbd963ad1014",              color:"#0097a7", url:"https://tvsen5.aynaott.com/PtvSports/index.m3u8?e=1780662761&u=78be6644-0a65-48ec-81a4-089ac65a2619&token=b714d4f0812496defe4be81125c560aa"},
  {id:16, name:"A Sports",          nameBn:"এ স্পোর্টস",               logo:"https://s3.aynaott.com/storage/64de30d2df9b2a888cb73f17614a9a8b",              color:"#7b1fa2", url:"https://tvsen6.aynaott.com/asports/index.m3u8?e=1780662762&u=78be6644-0a65-48ec-81a4-089ac65a2619&token=79cb2b10ec3a06c91dc483a6f1a04f36"},
  {id:17, name:"Cricket Gold",      nameBn:"ক্রিকেট গোল্ড",            logo:"https://s3.aynaott.com/storage/7d20b575edc4e4b5276faa8c246e72a4",              color:"#f9a825", url:"https://tvsen6.aynaott.com/CricketGold/index.m3u8?e=1780662762&u=78be6644-0a65-48ec-81a4-089ac65a2619&token=c1ffa5e779430e350c5cc5401c9b9bdc"},
  {id:18, name:"Willow TV",         nameBn:"উইলো টিভি",                logo:"https://s3.aynaott.com/storage/94a778ec3219f7eb54bdf1ee07a95788",              color:"#558b2f", url:"https://tvsen5.aynaott.com/willowhd/index.m3u8?e=1780662762&u=78be6644-0a65-48ec-81a4-089ac65a2619&token=7ff3de9f9a286f0a6df46787e8abd8fb"},
  {id:19, name:"DD Sports",         nameBn:"ডিডি স্পোর্টস",            logo:"https://s3.aynaott.com/storage/188500190395c4de0e506d518925dcc4",              color:"#1565c0", url:"https://cdn-6.pishow.tv/live/13/master.m3u8"},
];

const FLAGS = {"Mexico":"🇲🇽","United States":"🇺🇸","USA":"🇺🇸","Canada":"🇨🇦","Brazil":"🇧🇷","Argentina":"🇦🇷","France":"🇫🇷","Germany":"🇩🇪","Spain":"🇪🇸","England":"🏴󠁧󠁢󠁥󠁮󠁧󠁿","Portugal":"🇵🇹","Netherlands":"🇳🇱","Belgium":"🇧🇪","Italy":"🇮🇹","Japan":"🇯🇵","Australia":"🇦🇺","Morocco":"🇲🇦","Senegal":"🇸🇳","Nigeria":"🇳🇬","Saudi Arabia":"🇸🇦","Iran":"🇮🇷","Turkey":"🇹🇷","Switzerland":"🇨🇭","Croatia":"🇭🇷","Denmark":"🇩🇰","Poland":"🇵🇱","Serbia":"🇷🇸","Uruguay":"🇺🇾","Colombia":"🇨🇴","Ecuador":"🇪🇨","Indonesia":"🇮🇩","China":"🇨🇳","Qatar":"🇶🇦","Egypt":"🇪🇬","Ghana":"🇬🇭","South Africa":"🇿🇦","South Korea":"🇰🇷","Romania":"🇷🇴","Ukraine":"🇺🇦","Sweden":"🇸🇪","Algeria":"🇩🇿","Venezuela":"🇻🇪","Tunisia":"🇹🇳","Cameroon":"🇨🇲","New Zealand":"🇳🇿","Chile":"🇨🇱","Paraguay":"🇵🇾"};
const flag = (t) => FLAGS[t] || "🏳️";

const toUTC = (ds, ts) => {
  try {
    const m = (ts || "").match(/UTC([+-]?\d+(?:\.\d+)?)/);
    const off = m ? parseFloat(m[1]) : 0;
    const tp = (ts || "00:00").split(" ")[0];
    const [h, mn] = tp.split(":").map(Number);
    const d = new Date(ds + "T00:00:00Z");
    d.setUTCHours(h - off, mn || 0, 0, 0);
    return d;
  } catch { return null; }
};

const toBD = (ds, ts) => {
  const d = toUTC(ds, ts);
  if (!d) return ts || "TBA";
  const b = new Date(d.getTime() + 6 * 3600000);
  const h = b.getUTCHours(), mn = b.getUTCMinutes();
  return `${h % 12 || 12}:${String(mn).padStart(2, "0")} ${h >= 12 ? "PM" : "AM"} BD`;
};

const getCD = (ds, ts) => {
  const d = toUTC(ds, ts);
  if (!d) return null;
  const diff = d.getTime() - Date.now();
  if (diff <= 0 || diff > 48 * 3600000) return null;
  const h = Math.floor(diff / 3600000);
  const mn = Math.floor((diff % 3600000) / 60000);
  return h > 0 ? `${h}h ${mn}m বাকি` : `${mn}m বাকি`;
};

const todayStr = () => new Date().toISOString().split("T")[0];
const tmrStr = () => { const d = new Date(); d.setDate(d.getDate() + 1); return d.toISOString().split("T")[0]; };

// ── Channel Logo (safe - no onError string assignment) ──────
function ChLogo({ ch, size }) {
  const s = size || 40;
  const [err, setErr] = useState(false);
  if (ch.logo && ch.logo.startsWith("http") && !err) {
    return (
      <img
        src={ch.logo}
        alt={ch.name}
        onError={() => setErr(true)}
        style={{ width: s, height: s, borderRadius: Math.round(s * 0.22), objectFit: "contain", background: "#ffffff11", flexShrink: 0 }}
      />
    );
  }
  return <div style={{ fontSize: Math.round(s * 0.65), flexShrink: 0, lineHeight: 1 }}>{(ch.logo && !ch.logo.startsWith("http")) ? ch.logo : "📺"}</div>;
}

// ── FIFA Section ────────────────────────────────────────────
function FIFASection({ lang, channels }) {
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sv, setSv] = useState("banner");
  const [activeCh, setActiveCh] = useState(null);
  const [selDay, setSelDay] = useState("today");
  const [cds, setCds] = useState({});
  const [pState, setPState] = useState("loading");
  const vidRef = useRef(null);
  const hlsRef = useRef(null);
  const bn = lang === "bn";

  // Load hls.js via script tag (not dynamic import)
  useEffect(() => {
    if (window.Hls || document.getElementById("hlsjs-cdn")) return;
    const s = document.createElement("script");
    s.id = "hlsjs-cdn";
    s.src = "https://cdn.jsdelivr.net/npm/hls.js@1.5.13/dist/hls.min.js";
    document.head.appendChild(s);
  }, []);

  // Fetch match data
  useEffect(() => {
    const load = async () => {
      try {
        const r = await fetch("https://worldcup26.ir/get/games");
        if (!r.ok) throw new Error();
        const d = await r.json();
        setMatches(Array.isArray(d) ? d : (d.matches || d.games || []));
      } catch {
        try {
          const r2 = await fetch("https://raw.githubusercontent.com/openfootball/worldcup.json/master/2026/worldcup.json");
          const d2 = await r2.json();
          setMatches(d2.matches || []);
        } catch {}
      } finally { setLoading(false); }
    };
    load();
    const iv = setInterval(load, 5 * 60 * 1000);
    return () => clearInterval(iv);
  }, []);

  // Countdown ticker
  useEffect(() => {
    const tick = () => {
      const m = {};
      matches.forEach((match, i) => {
        const c = getCD(match.date || match.datetime?.split("T")[0] || "", match.time || match.datetime || "");
        if (c) m[i] = c;
      });
      setCds(m);
    };
    tick();
    const iv = setInterval(tick, 30000);
    return () => clearInterval(iv);
  }, [matches]);

  // HLS Player — iframe + video fallback approach
  useEffect(() => {
    if (sv !== "player" || !activeCh) return;
    setPState("loading");
    // Load hls.js
    if (!window.Hls && !document.getElementById("hlsjs-cdn")) {
      const s = document.createElement("script");
      s.id = "hlsjs-cdn";
      s.src = "https://cdn.jsdelivr.net/npm/hls.js@1.5.13/dist/hls.min.js";
      document.head.appendChild(s);
    }
    if (hlsRef.current) { hlsRef.current.destroy(); hlsRef.current = null; }
    const vid = vidRef.current;
    if (!vid) return;
    vid.src = "";

    const tryPlay = () => {
      const url = activeCh.url;
      // Safari / iOS native HLS
      if (vid.canPlayType("application/vnd.apple.mpegurl")) {
        vid.src = url;
        vid.load();
        vid.play().catch(() => setPState("error"));
        return;
      }
      const Hls = window.Hls;
      if (!Hls || !Hls.isSupported()) {
        vid.src = url; vid.load(); vid.play().catch(() => setPState("error"));
        return;
      }
      const hls = new Hls({
        lowLatencyMode: true,
        enableWorker: false,
        xhrSetup: (xhr, reqUrl) => {
          xhr.withCredentials = false;
          // CORS proxy শুধু প্রয়োজনীয় domains এ
          if (reqUrl && (reqUrl.includes("gpcdn.net") || reqUrl.includes("zohanayaan.com") || reqUrl.includes("aynaott.com") || reqUrl.includes("pishow.tv"))) {
            // প্রথমে direct try, fail হলে proxy
          }
        },
      });
      hlsRef.current = hls;
      hls.loadSource(url);
      hls.attachMedia(vid);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        vid.play().catch(() => {});
      });
      hls.on(Hls.Events.ERROR, (_, data) => {
        console.log("HLS Error:", data.type, data.details);
        if (data.fatal) {
          if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
            // Network error — proxy দিয়ে retry
            hls.destroy();
            hlsRef.current = null;
            const hls2 = new Hls({ lowLatencyMode: true, enableWorker: false });
            hlsRef.current = hls2;
            const proxyUrl = "https://corsproxy.io/?url=" + encodeURIComponent(url);
            hls2.loadSource(proxyUrl);
            hls2.attachMedia(vid);
            hls2.on(Hls.Events.MANIFEST_PARSED, () => vid.play().catch(() => {}));
            hls2.on(Hls.Events.ERROR, () => setPState("error"));
          } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
            hls.recoverMediaError();
          } else {
            setPState("error");
          }
        }
      });
    };

    if (window.Hls) {
      tryPlay();
    } else {
      const iv = setInterval(() => { if (window.Hls) { clearInterval(iv); tryPlay(); } }, 150);
      return () => clearInterval(iv);
    }
    return () => { if (hlsRef.current) { hlsRef.current.destroy(); hlsRef.current = null; } };
  }, [sv, activeCh]);

  const fdate = selDay === "today" ? todayStr() : tmrStr();
  const dayM = matches.filter(m => (m.date || m.datetime?.split("T")[0] || "") === fdate);

  if (sv === "banner") return (
    <div style={{ marginBottom: 8 }}>
      <div
        onClick={() => setSv("channels")}
        style={{ background: "linear-gradient(135deg,#08081a,#140a2a,#081528)", border: "1px solid #c8a96e44", borderRadius: 18, padding: "16px 16px 13px", cursor: "pointer", position: "relative", overflow: "hidden", marginBottom: 10 }}
      >
        <div style={{ position: "absolute", top: -20, right: -20, fontSize: 130, opacity: .04, pointerEvents: "none", userSelect: "none" }}>⚽</div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 11 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 22 }}>🏆</span>
            <div>
              <div style={{ fontSize: 13, fontWeight: 800, color: "#c8a96e" }}>{bn ? "ফিফা বিশ্বকাপ ২০২৬" : "FIFA World Cup 2026"}</div>
              <div style={{ fontSize: 9, opacity: .38, letterSpacing: 1.5 }}>USA · CANADA · MEXICO</div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 5, background: "#e0525218", border: "1px solid #e0525255", borderRadius: 20, padding: "4px 10px" }}>
            <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#e05252", animation: "pulse 1.2s infinite" }} />
            <span style={{ fontSize: 10, fontWeight: 800, color: "#e05252" }}>LIVE</span>
          </div>
        </div>
        {loading
          ? <div style={{ textAlign: "center", padding: "14px 0", opacity: .3, fontSize: 12 }}>⏳ {bn ? "লোড হচ্ছে..." : "Loading..."}</div>
          : dayM.length === 0
            ? <div style={{ textAlign: "center", padding: "14px 0", opacity: .28, fontSize: 12 }}>📅 {bn ? "আজ কোনো ম্যাচ নেই" : "No matches today"}</div>
            : dayM.slice(0, 2).map((m, i) => {
                const t1 = m.team1 || m.home_team?.name || "TBD";
                const t2 = m.team2 || m.away_team?.name || "TBD";
                const sc = m.score?.ft ? `${m.score.ft[0]}-${m.score.ft[1]}` : null;
                const bd = toBD(m.date || m.datetime?.split("T")[0], m.time || m.datetime);
                const cd = cds[matches.indexOf(m)];
                return (
                  <div key={i} style={{ background: "#ffffff09", borderRadius: 10, padding: "9px 12px", marginBottom: 7, display: "flex", alignItems: "center", gap: 6 }}>
                    <span style={{ fontSize: 20 }}>{flag(t1)}</span>
                    <span style={{ fontSize: 12, fontWeight: 700, flex: 1 }}>{t1}</span>
                    <div style={{ textAlign: "center", minWidth: 50 }}>
                      <div style={{ fontSize: sc ? 16 : 11, fontWeight: 900, color: "#c8a96e" }}>{sc || "VS"}</div>
                      {cd && !sc && <div style={{ fontSize: 9, color: "#69f0ae", fontWeight: 700 }}>⏰ {cd}</div>}
                    </div>
                    <span style={{ fontSize: 12, fontWeight: 700, flex: 1, textAlign: "right" }}>{t2}</span>
                    <span style={{ fontSize: 20 }}>{flag(t2)}</span>
                    <span style={{ fontSize: 9, opacity: .32, marginLeft: 4, whiteSpace: "nowrap", flexShrink: 0 }}>{bd}</span>
                  </div>
                );
              })
        }
        {dayM.length > 2 && <div style={{ fontSize: 10, opacity: .28, textAlign: "center", marginTop: 2 }}>+{dayM.length - 2}{bn ? "টি আরো ম্যাচ" : " more matches"}</div>}
        <div style={{ marginTop: 12, background: "linear-gradient(135deg,#c8a96e,#e8c98e)", borderRadius: 10, padding: "10px 0", textAlign: "center", color: "#070710", fontWeight: 800, fontSize: 13 }}>
          📺 {bn ? "লাইভ দেখুন →" : "Watch Live →"}
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
        {["today", "tomorrow"].map(d => (
          <button key={d} onClick={() => setSelDay(d)} style={{ padding: "7px 16px", borderRadius: 50, fontSize: 12, fontWeight: 700, cursor: "pointer", border: "none", fontFamily: "inherit", background: selDay === d ? "linear-gradient(135deg,#c8a96e,#e8c98e)" : "#11111e", color: selDay === d ? "#070710" : "#f0ece377" }}>
            {d === "today" ? (bn ? "📅 আজকের ম্যাচ" : "📅 Today") : (bn ? "⏩ আগামীকাল" : "⏩ Tomorrow")}
          </button>
        ))}
      </div>

      {!loading && dayM.map((m, i) => {
        const t1 = m.team1 || m.home_team?.name || "TBD";
        const t2 = m.team2 || m.away_team?.name || "TBD";
        const sc = m.score?.ft ? `${m.score.ft[0]} – ${m.score.ft[1]}` : null;
        const bd = toBD(m.date || m.datetime?.split("T")[0], m.time || m.datetime);
        const cd = cds[i];
        const live = m.status === "live" || m.status === "in_play";
        return (
          <div key={i} onClick={() => setSv("channels")} style={{ background: "linear-gradient(145deg,#0c0c1e,#12122a)", border: `1px solid ${live ? "#e0525244" : "#22223a"}`, borderRadius: 14, padding: "12px 14px", marginBottom: 8, cursor: "pointer" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 9 }}>
              <span style={{ fontSize: 10, color: "#c8a96e88", fontWeight: 700 }}>{m.group || m.round || ""}</span>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                {live && <><div style={{ width: 6, height: 6, borderRadius: "50%", background: "#e05252", animation: "pulse 1s infinite" }} /><span style={{ fontSize: 10, color: "#e05252", fontWeight: 800 }}>LIVE</span></>}
                {cd && !sc && !live && <span style={{ fontSize: 10, color: "#69f0ae", fontWeight: 700, background: "#69f0ae18", padding: "2px 8px", borderRadius: 10 }}>⏰ {cd}</span>}
                <span style={{ fontSize: 10, opacity: .35 }}>{bd}</span>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ flex: 1, textAlign: "center" }}>
                <div style={{ fontSize: 26, marginBottom: 3 }}>{flag(t1)}</div>
                <div style={{ fontSize: 12, fontWeight: 700, lineHeight: 1.2 }}>{t1}</div>
              </div>
              <div style={{ padding: "0 10px", textAlign: "center", minWidth: 54 }}>
                {sc ? <div style={{ fontSize: 20, fontWeight: 900, color: "#c8a96e" }}>{sc}</div>
                    : <div style={{ fontSize: 12, fontWeight: 900, color: "#c8a96e44", letterSpacing: 2 }}>VS</div>}
              </div>
              <div style={{ flex: 1, textAlign: "center" }}>
                <div style={{ fontSize: 26, marginBottom: 3 }}>{flag(t2)}</div>
                <div style={{ fontSize: 12, fontWeight: 700, lineHeight: 1.2 }}>{t2}</div>
              </div>
            </div>
            {(m.ground || m.venue) && <div style={{ fontSize: 9, opacity: .22, textAlign: "center", marginTop: 7 }}>📍 {m.ground || m.venue}</div>}
          </div>
        );
      })}
    </div>
  );

  if (sv === "channels") return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <button onClick={() => setSv("banner")} style={{ background: "#11111e", border: "1px solid #22223a", color: "#c8a96e", borderRadius: 10, padding: "8px 14px", cursor: "pointer", fontWeight: 700, fontFamily: "inherit", fontSize: 16 }}>←</button>
        <div>
          <div style={{ fontWeight: 800, fontSize: 14 }}>📺 {bn ? "চ্যানেল বেছে নিন" : "Select Channel"}</div>
          <div style={{ fontSize: 10, opacity: .33 }}>{bn ? "ট্যাপ করুন লাইভ দেখতে" : "Tap to watch live"}</div>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {channels.map(ch => (
          <div
            key={ch.id}
            onClick={() => { setPState("loading"); setActiveCh(ch); setSv("player"); }}
            style={{ background: "linear-gradient(145deg,#0c0c1e,#12122a)", border: `1px solid ${ch.color}33`, borderRadius: 14, padding: 13, cursor: "pointer", textAlign: "center" }}
          >
            <div style={{ display: "flex", justifyContent: "center", marginBottom: 8 }}>
              <ChLogo ch={ch} size={44} />
            </div>
            <div style={{ fontWeight: 800, fontSize: 12, color: ch.color, lineHeight: 1.3 }}>{ch.name}</div>
            <div style={{ fontSize: 10, opacity: .35, marginTop: 2 }}>{ch.nameBn}</div>
            <div style={{ marginTop: 9, background: `${ch.color}22`, border: `1px solid ${ch.color}44`, borderRadius: 8, padding: "5px 0", fontSize: 11, fontWeight: 700, color: ch.color }}>▶ Watch Live</div>
          </div>
        ))}
      </div>
    </div>
  );

  if (sv === "player" && activeCh) return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 11 }}>
        <button
          onClick={() => { setSv("channels"); if (hlsRef.current) { hlsRef.current.destroy(); hlsRef.current = null; } }}
          style={{ background: "#11111e", border: "1px solid #22223a", color: "#c8a96e", borderRadius: 10, padding: "8px 14px", cursor: "pointer", fontWeight: 700, fontFamily: "inherit", fontSize: 16 }}
        >←</button>
        <ChLogo ch={activeCh} size={34} />
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 800, fontSize: 13, color: activeCh.color }}>{activeCh.name}</div>
          <div style={{ fontSize: 10, opacity: .33 }}>{activeCh.nameBn}</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 5, background: "#e0525218", border: "1px solid #e0525244", borderRadius: 16, padding: "3px 9px" }}>
          <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#e05252", animation: "pulse 1.2s infinite" }} />
          <span style={{ fontSize: 10, fontWeight: 800, color: "#e05252" }}>LIVE</span>
        </div>
      </div>

      <div style={{ background: "#000", borderRadius: 14, overflow: "hidden", aspectRatio: "16/9", position: "relative", border: "1px solid #22223a", marginBottom: 11 }}>
        <video
          ref={vidRef}
          controls autoPlay playsInline
          onPlaying={() => setPState("playing")}
          onWaiting={() => { if (pState !== "error") setPState("loading"); }}
          onError={() => setPState("error")}
          style={{ width: "100%", height: "100%", display: "block", background: "#000" }}
        />
        {pState === "loading" && (
          <div style={{ position: "absolute", inset: 0, background: "#000000bb", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12, pointerEvents: "none" }}>
            <div style={{ width: 42, height: 42, border: "3px solid #c8a96e33", borderTop: "3px solid #c8a96e", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
            <span style={{ fontSize: 12, color: "#c8a96e", fontWeight: 600 }}>{bn ? "লোড হচ্ছে..." : "Loading..."}</span>
          </div>
        )}
        {pState === "error" && (
          <div style={{ position: "absolute", inset: 0, background: "#000000cc", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10, padding: 20 }}>
            <span style={{ fontSize: 34 }}>📡</span>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#e05252", textAlign: "center" }}>{bn ? "ব্রাউজার CORS block করছে" : "Browser CORS Blocked"}</div>
            <div style={{ fontSize: 11, opacity: .5, textAlign: "center", lineHeight: 1.6 }}>{bn ? "এই চ্যানেলটি সরাসরি খুলতে নিচের বোতামে চাপুন" : "Tap below to open this channel directly"}</div>
            <a href={activeCh.url} target="_blank" rel="noreferrer" style={{ textDecoration: "none", width: "100%" }}>
              <button style={{ background: "linear-gradient(135deg,#c8a96e,#e8c98e)", border: "none", borderRadius: 9, padding: "10px 0", fontWeight: 800, cursor: "pointer", fontFamily: "inherit", color: "#070710", fontSize: 13, width: "100%" }}>
                🔗 {bn ? "VLC / Browser-এ খুলুন" : "Open in VLC / Browser"}
              </button>
            </a>
            <button
              onClick={() => { const ch = activeCh; setActiveCh(null); setPState("loading"); setTimeout(() => setActiveCh(ch), 200); }}
              style={{ background: "#ffffff0a", border: "1px solid #ffffff22", borderRadius: 9, padding: "8px 0", fontWeight: 600, cursor: "pointer", fontFamily: "inherit", color: "#f0ece3aa", fontSize: 12, width: "100%" }}
            >🔄 {bn ? "আবার চেষ্টা" : "Retry"}</button>
          </div>
        )}
      </div>

      {dayM.length > 0 && (
        <div style={{ background: "#0c0c1e", border: "1px solid #22223a", borderRadius: 12, padding: "12px 15px", marginBottom: 11 }}>
          <div style={{ fontSize: 11, color: "#e05252", fontWeight: 700, marginBottom: 8 }}>🔴 {bn ? "আজকের ম্যাচ" : "Today's Matches"}</div>
          {dayM.map((m, i) => {
            const t1 = m.team1 || m.home_team?.name || "TBD";
            const t2 = m.team2 || m.away_team?.name || "TBD";
            const bd = toBD(m.date || m.datetime?.split("T")[0], m.time || m.datetime);
            const cd = cds[i];
            return (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 12, padding: "5px 0", borderBottom: i < dayM.length - 1 ? "1px solid #1e1e34" : "none" }}>
                <span>{flag(t1)} {t1} vs {t2} {flag(t2)}</span>
                <div style={{ textAlign: "right", flexShrink: 0, marginLeft: 8 }}>
                  <div style={{ fontSize: 10, opacity: .33 }}>{bd}</div>
                  {cd && <div style={{ fontSize: 9, color: "#69f0ae", fontWeight: 700 }}>⏰ {cd}</div>}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div style={{ fontSize: 10, opacity: .3, marginBottom: 7, fontWeight: 600 }}>{bn ? "অন্য চ্যানেল:" : "Switch channel:"}</div>
      <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 4 }}>
        {channels.filter(c => c.id !== activeCh.id).map(ch => (
          <div
            key={ch.id}
            onClick={() => { if (hlsRef.current) { hlsRef.current.destroy(); hlsRef.current = null; } setPState("loading"); setActiveCh(ch); }}
            style={{ flexShrink: 0, background: "#11111e", border: `1px solid ${ch.color}44`, borderRadius: 10, padding: "7px 11px", cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}
          >
            <ChLogo ch={ch} size={22} />
            <span style={{ fontSize: 11, fontWeight: 700, color: ch.color, whiteSpace: "nowrap" }}>{ch.name}</span>
          </div>
        ))}
      </div>
    </div>
  );

  return null;
}

// ── Admin Panel ─────────────────────────────────────────────
function AdminPanel({ channels, setChannels, onClose }) {
  const [editId, setEditId] = useState(null);
  const [isNew, setIsNew] = useState(false);
  const [form, setForm] = useState({});
  const [delId, setDelId] = useState(null);

  const startEdit = ch => { setEditId(ch.id); setIsNew(false); setForm({ ...ch }); };
  const startNew = () => { setEditId("new"); setIsNew(true); setForm({ id: Date.now(), name: "", nameBn: "", logo: "📺", color: "#c8a96e", url: "" }); };
  const upd = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const save = () => {
    if (!form.name || !form.url) { alert("নাম ও URL দিন"); return; }
    if (isNew) setChannels(p => [...p, form]);
    else setChannels(p => p.map(c => c.id === editId ? form : c));
    setEditId(null);
  };
  const del = id => { setChannels(p => p.filter(c => c.id !== id)); setDelId(null); };

  return (
    <div style={{ position: "fixed", inset: 0, background: "#000000d0", zIndex: 9000, overflowY: "auto", padding: "20px 12px" }}>
      <div style={{ maxWidth: 480, margin: "0 auto", background: "#0c0c1e", borderRadius: 18, border: "1px solid #c8a96e44", padding: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 800, color: "#c8a96e" }}>⚙️ অ্যাডমিন প্যানেল</div>
            <div style={{ fontSize: 10, opacity: .33 }}>চ্যানেল ম্যানেজমেন্ট</div>
          </div>
          <button onClick={onClose} style={{ background: "#e0525222", border: "1px solid #e0525244", color: "#e05252", borderRadius: 10, padding: "6px 14px", cursor: "pointer", fontWeight: 700, fontFamily: "inherit" }}>✕ বন্ধ</button>
        </div>

        {editId ? (
          <div style={{ background: "#12122a", border: "1px solid #c8a96e33", borderRadius: 14, padding: 16, marginBottom: 14 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#c8a96e", marginBottom: 12 }}>{isNew ? "➕ নতুন চ্যানেল" : "✏️ চ্যানেল এডিট"}</div>
            {[
              { k: "name", lb: "চ্যানেল নাম (EN)", ph: "T Sports HD" },
              { k: "nameBn", lb: "নাম (বাংলা)", ph: "টি স্পোর্টস" },
              { k: "logo", lb: "লোগো URL বা ইমোজি", ph: "📺 বা https://..." },
              { k: "color", lb: "রঙ HEX", ph: "#e63946" },
              { k: "url", lb: "m3u8 URL ★", ph: "https://....m3u8" },
            ].map(f => (
              <div key={f.k} style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 11, opacity: .45, marginBottom: 4, display: "block" }}>{f.lb}</label>
                <input value={form[f.k] || ""} onChange={e => upd(f.k, e.target.value)} placeholder={f.ph}
                  style={{ background: "#0c0c1e", border: "1.5px solid #22223a", borderRadius: 9, color: "#f0ece3", padding: "9px 12px", fontSize: 13, fontFamily: "inherit", width: "100%", outline: "none" }} />
              </div>
            ))}
            <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
              <button onClick={save} style={{ flex: 1, background: "linear-gradient(135deg,#c8a96e,#e8c98e)", border: "none", borderRadius: 9, padding: "10px 0", fontWeight: 800, fontSize: 13, cursor: "pointer", fontFamily: "inherit", color: "#070710" }}>💾 সেভ</button>
              <button onClick={() => setEditId(null)} style={{ background: "#ffffff0a", border: "1px solid #ffffff14", color: "#f0ece3", borderRadius: 9, padding: "10px 14px", cursor: "pointer", fontFamily: "inherit", fontWeight: 600 }}>বাতিল</button>
            </div>
          </div>
        ) : (
          <button onClick={startNew} style={{ width: "100%", background: "#c8a96e18", border: "1px dashed #c8a96e66", borderRadius: 12, padding: "11px 0", color: "#c8a96e", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "inherit", marginBottom: 13 }}>
            ➕ নতুন চ্যানেল যোগ করুন
          </button>
        )}

        <div style={{ fontSize: 10, opacity: .28, marginBottom: 8 }}>{channels.length}টি চ্যানেল</div>
        <div style={{ maxHeight: 400, overflowY: "auto", display: "flex", flexDirection: "column", gap: 7 }}>
          {channels.map((ch, idx) => (
            <div key={ch.id} style={{ background: "#12122a", border: `1px solid ${ch.color}33`, borderRadius: 12, padding: "10px 13px", display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 10, opacity: .22, minWidth: 16 }}>{idx + 1}</span>
              <ChLogo ch={ch} size={30} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: ch.color, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{ch.name}</div>
                <div style={{ fontSize: 9, opacity: .28, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{ch.url.slice(0, 42)}...</div>
              </div>
              <div style={{ display: "flex", gap: 5, flexShrink: 0 }}>
                <button onClick={() => startEdit(ch)} style={{ background: "#c8a96e18", border: "1px solid #c8a96e44", color: "#c8a96e", borderRadius: 7, padding: "4px 9px", cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>✏️</button>
                {delId === ch.id
                  ? <button onClick={() => del(ch.id)} style={{ background: "#e0525222", border: "1px solid #e05252", color: "#e05252", borderRadius: 7, padding: "4px 9px", cursor: "pointer", fontSize: 10, fontFamily: "inherit", fontWeight: 700 }}>নিশ্চিত?</button>
                  : <button onClick={() => setDelId(ch.id)} style={{ background: "#e0525211", border: "1px solid #e0525233", color: "#e05252", borderRadius: 7, padding: "4px 9px", cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>🗑️</button>
                }
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Products & Data ─────────────────────────────────────────
const PRODUCTS = [
  { id: 1,  name: "SKMEI Sport Watch",   nameBn: "স্কমেই স্পোর্ট ঘড়ি",     price: 850,  orig: 1200, emoji: "⌚", cat: "watches",   r: 4.5, rv: 42, stk: 15, hot: true },
  { id: 2,  name: "CURREN Classic",      nameBn: "কারেন ক্লাসিক ঘড়ি",      price: 1400, orig: 1800, emoji: "🕰️", cat: "watches",   r: 4.7, rv: 31, stk: 8,  hot: false },
  { id: 3,  name: "SMAEL Military",      nameBn: "স্মাইল মিলিটারি ঘড়ি",    price: 950,  orig: 1300, emoji: "⌚", cat: "watches",   r: 4.3, rv: 55, stk: 20, hot: true },
  { id: 4,  name: "SKMEI Digital LED",   nameBn: "স্কমেই ডিজিটাল",          price: 650,  orig: 900,  emoji: "🖥️", cat: "watches",   r: 4.4, rv: 78, stk: 30, hot: false },
  { id: 5,  name: "Gold Chain Necklace", nameBn: "গোল্ড চেইন নেকলেস",       price: 750,  orig: 1100, emoji: "📿", cat: "jewellery", r: 4.6, rv: 29, stk: 18, hot: true },
  { id: 6,  name: "Silver Bracelet",     nameBn: "সিলভার ব্রেসলেট",         price: 480,  orig: 700,  emoji: "💍", cat: "jewellery", r: 4.4, rv: 44, stk: 22, hot: false },
  { id: 7,  name: "Pearl Earrings",      nameBn: "পার্ল ইয়ারিং",            price: 390,  orig: 600,  emoji: "💎", cat: "jewellery", r: 4.5, rv: 37, stk: 15, hot: false },
  { id: 8,  name: "Nike Air Style",      nameBn: "নাইকি এয়ার স্টাইল",      price: 1800, orig: 2500, emoji: "👟", cat: "sneakers",  r: 4.8, rv: 61, stk: 10, hot: true },
  { id: 9,  name: "Casual Sneakers",     nameBn: "ক্যাজুয়াল স্নিকার্স",    price: 1100, orig: 1600, emoji: "👟", cat: "sneakers",  r: 4.3, rv: 38, stk: 14, hot: false },
  { id: 10, name: "Running Shoes",       nameBn: "রানিং শু",                 price: 1350, orig: 1900, emoji: "🏃", cat: "sneakers",  r: 4.6, rv: 52, stk: 9,  hot: true },
  { id: 11, name: "Premium Cotton Tee",  nameBn: "প্রিমিয়াম কটন টিশার্ট",  price: 420,  orig: 650,  emoji: "👕", cat: "tshirts",   r: 4.5, rv: 88, stk: 40, hot: true },
  { id: 12, name: "Graphic Print Tee",   nameBn: "গ্রাফিক প্রিন্ট টিশার্ট",price: 380,  orig: 550,  emoji: "🎨", cat: "tshirts",   r: 4.2, rv: 65, stk: 35, hot: false },
  { id: 13, name: "Polo Shirt",          nameBn: "পোলো শার্ট",               price: 550,  orig: 800,  emoji: "👔", cat: "tshirts",   r: 4.6, rv: 47, stk: 25, hot: false },
];

const CATS = [
  { id: "all",      bn: "সব পণ্য",    en: "All",       ic: "🛍️" },
  { id: "watches",  bn: "ওয়াচেস",    en: "Watches",   ic: "⌚" },
  { id: "jewellery",bn: "জুয়েলারি",  en: "Jewellery", ic: "💍" },
  { id: "sneakers", bn: "স্নেকার্স",  en: "Sneakers",  ic: "👟" },
  { id: "tshirts",  bn: "টি-শার্ট",   en: "T-Shirts",  ic: "👕" },
];

const SLIDES = [
  { id: 1, tBn: "ঈদ স্পেশাল অফার!", tEn: "Eid Special Offer!", sBn: "সকল পণ্যে ৩০% পর্যন্ত ছাড়", sEn: "Up to 30% off on all products", bBn: "সীমিত সময়", bEn: "Limited Time", e: "🎉", bg: "linear-gradient(135deg,#1a0a2e,#2d1060)", ac: "#c8a96e" },
  { id: 2, tBn: "প্রিমিয়াম ঘড়ি",   tEn: "Premium Watches",    sBn: "SKMEI • CURREN • SMAEL",       sEn: "SKMEI • CURREN • SMAEL",          bBn: "নতুন আগমন", bEn: "New Arrival", e: "⌚", bg: "linear-gradient(135deg,#0a1a2e,#102040)", ac: "#4fc3f7" },
  { id: 3, tBn: "ফ্রি ডেলিভারি!",   tEn: "Free Delivery!",     sBn: "১০০০ টাকার উপরে সকল অর্ডারে", sEn: "On all orders above ৳1,000",      bBn: "অফার চলছে", bEn: "Running",     e: "🚚", bg: "linear-gradient(135deg,#0a2e1a,#104028)", ac: "#69f0ae" },
  { id: 4, tBn: "জুয়েলারি সেল",     tEn: "Jewellery Sale",     sBn: "গোল্ড ও সিলভার কালেকশন",      sEn: "Gold & Silver Collection",        bBn: "হট ডিল",    bEn: "Hot Deal",    e: "💍", bg: "linear-gradient(135deg,#2e1a0a,#402810)", ac: "#ffcc80" },
];

// ── Main App ────────────────────────────────────────────────
export default function App() {
  const [cart, setCart]         = useState([]);
  const [view, setView]         = useState("shop");
  const [cat, setCat]           = useState("all");
  const [search, setSearch]     = useState("");
  const [sIdx, setSIdx]         = useState(0);
  const [toast, setToast]       = useState(null);
  const [form, setForm]         = useState({ name: "", phone: "", address: "", district: "", area: "dhaka" });
  const [order, setOrder]       = useState(null);
  const [lang, setLang]         = useState("bn");
  const [channels, setChannels] = useState(DEFAULT_CHANNELS);
  const [showAdmin, setShowAdmin]   = useState(false);
  const [adminAuth, setAdminAuth]   = useState(false);
  const [adminPw, setAdminPw]       = useState("");
  const slTimer = useRef(null);
  const bn = lang === "bn";

  useEffect(() => {
    slTimer.current = setInterval(() => setSIdx(i => (i + 1) % SLIDES.length), 3400);
    return () => clearInterval(slTimer.current);
  }, []);

  const showToast = msg => { setToast(msg); setTimeout(() => setToast(null), 2500); };

  const addCart = p => {
    setCart(prev => {
      const ex = prev.find(i => i.id === p.id);
      return ex ? prev.map(i => i.id === p.id ? { ...i, qty: i.qty + 1 } : i) : [...prev, { ...p, qty: 1 }];
    });
    showToast(`✅ ${bn ? p.nameBn : p.name} ${bn ? "কার্টে যোগ হয়েছে" : "added to cart"}`);
  };

  const buyNow = p => { addCart(p); setView("cart"); };
  const remCart = id => setCart(p => p.filter(i => i.id !== id));
  const updQty = (id, d) => setCart(p => p.map(i => i.id === id ? { ...i, qty: Math.max(1, i.qty + d) } : i));

  const cartCnt = cart.reduce((s, i) => s + i.qty, 0);
  const cartSub = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const delAmt  = cartSub >= 1000 ? 0 : form.area === "dhaka" ? 70 : 120;
  const grand   = cartSub + delAmt;

  const filtered = PRODUCTS.filter(p =>
    (cat === "all" || p.cat === cat) &&
    (p.name.toLowerCase().includes(search.toLowerCase()) || p.nameBn.includes(search))
  );

  const sl = SLIDES[sIdx];

  const placeOrder = () => {
    if (!form.name || !form.phone || !form.address || !form.district) {
      showToast(bn ? "⚠️ সব তথ্য পূরণ করুন" : "⚠️ Fill all fields");
      return;
    }
    const oid = "NGS" + Date.now().toString().slice(-6);
    setOrder({ ...form, oid, items: [...cart], sub: cartSub, del: delAmt, grand });
    setCart([]);
    setView("success");
  };

  return (
    <div style={{ fontFamily: "'Hind Siliguri','Noto Sans Bengali',sans-serif", background: "#070710", minHeight: "100vh", color: "#f0ece3", paddingBottom: 80 }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&family=Playfair+Display:wght@700;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:#c8a96e;border-radius:2px}
        .card{background:linear-gradient(145deg,#111120,#161628);border:1px solid #22223a;border-radius:16px;overflow:hidden;transition:transform .22s,box-shadow .22s}
        .card:hover{transform:translateY(-3px);box-shadow:0 12px 32px rgba(200,169,110,.12)}
        .bg{background:linear-gradient(135deg,#c8a96e,#e8c98e);color:#070710;border:none;border-radius:10px;padding:10px 16px;font-weight:700;cursor:pointer;font-size:13px;font-family:inherit;width:100%}
        .bg:hover{opacity:.9}
        .bo{background:transparent;border:1.5px solid #c8a96e;color:#c8a96e;border-radius:10px;padding:9px 16px;font-weight:600;cursor:pointer;font-size:13px;font-family:inherit;width:100%}
        .bgh{background:#ffffff0a;border:1px solid #ffffff14;color:#f0ece3;border-radius:10px;padding:9px 16px;font-weight:600;cursor:pointer;font-size:13px;font-family:inherit;width:100%}
        input,select{background:#11111e;border:1.5px solid #22223a;border-radius:10px;color:#f0ece3;padding:11px 14px;font-size:14px;font-family:inherit;width:100%;outline:none;transition:border .2s}
        input:focus,select:focus{border-color:#c8a96e}
        .ir{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #22223a;font-size:13px}
        .ir:last-child{border:none}
        .pill{display:flex;align-items:center;gap:6px;padding:8px 16px;border-radius:50px;font-size:13px;font-weight:600;cursor:pointer;border:none;font-family:inherit;white-space:nowrap;flex-shrink:0}
        .toast{position:fixed;bottom:28px;left:50%;transform:translateX(-50%);background:#16162a;border:1px solid #c8a96e;color:#f0ece3;padding:11px 22px;border-radius:50px;font-size:13px;font-weight:500;z-index:9999;white-space:nowrap;box-shadow:0 8px 30px rgba(0,0,0,.6);animation:tIn .3s ease}
        @keyframes tIn{from{opacity:0;transform:translateX(-50%) translateY(8px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
        @keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.5;transform:scale(1.35)}}
        @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
        .fl{color:#c8a96e88;font-size:12px;cursor:pointer}
        .wb{display:flex;align-items:center;justify-content:center;gap:10px;background:linear-gradient(135deg,#25d366,#128c7e);color:#fff;border:none;border-radius:14px;padding:14px 24px;font-size:15px;font-weight:700;cursor:pointer;width:100%;font-family:inherit}
      `}</style>

      {showAdmin && adminAuth && (
        <AdminPanel channels={channels} setChannels={setChannels} onClose={() => { setShowAdmin(false); setAdminAuth(false); setAdminPw(""); }} />
      )}
      {showAdmin && !adminAuth && (
        <div style={{ position: "fixed", inset: 0, background: "#000000d0", zIndex: 9000, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <div style={{ background: "#0c0c1e", border: "1px solid #c8a96e44", borderRadius: 18, padding: 24, width: "100%", maxWidth: 320 }}>
            <div style={{ fontSize: 16, fontWeight: 800, color: "#c8a96e", marginBottom: 4 }}>🔐 অ্যাডমিন</div>
            <div style={{ fontSize: 11, opacity: .33, marginBottom: 14 }}>পাসওয়ার্ড দিয়ে প্রবেশ করুন</div>
            <input type="password" placeholder="পাসওয়ার্ড" value={adminPw} onChange={e => setAdminPw(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter") { if (adminPw === ADMIN_PASS) setAdminAuth(true); else showToast("❌ ভুল পাসওয়ার্ড"); } }}
              style={{ marginBottom: 12 }} />
            <div style={{ display: "flex", gap: 8 }}>
              <button className="bg" onClick={() => { if (adminPw === ADMIN_PASS) setAdminAuth(true); else showToast("❌ ভুল পাসওয়ার্ড"); }} style={{ padding: "10px 0" }}>প্রবেশ</button>
              <button className="bgh" onClick={() => { setShowAdmin(false); setAdminPw(""); }} style={{ width: "auto", padding: "10px 16px" }}>বাতিল</button>
            </div>
          </div>
        </div>
      )}

      {/* NAVBAR */}
      <nav style={{ background: "#0a0a18", borderBottom: "1px solid #1e1e34", padding: "0 16px", position: "sticky", top: 0, zIndex: 200, height: 58, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div onClick={() => setView("shop")} style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: "linear-gradient(135deg,#c8a96e,#e8c98e)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 900, color: "#070710", fontFamily: "serif", flexShrink: 0 }}>N</div>
          <div>
            <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 16, fontWeight: 900, color: "#c8a96e", lineHeight: 1 }}>NextGen Style</div>
            <div style={{ fontSize: 9, opacity: .38, letterSpacing: 2.5 }}>BD · LIFESTYLE STORE</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 3, alignItems: "center" }}>
          <div style={{ display: "flex", background: "#11111e", border: "1px solid #22223a", borderRadius: 20, padding: 3, gap: 2, marginRight: 4 }}>
            <button onClick={() => setLang("bn")} style={{ background: lang === "bn" ? "linear-gradient(135deg,#c8a96e,#e8c98e)" : "transparent", border: "none", color: lang === "bn" ? "#070710" : "#f0ece366", padding: "4px 9px", borderRadius: 15, cursor: "pointer", fontSize: 11, fontWeight: 700, fontFamily: "inherit" }}>বাং</button>
            <button onClick={() => setLang("en")} style={{ background: lang === "en" ? "linear-gradient(135deg,#c8a96e,#e8c98e)" : "transparent", border: "none", color: lang === "en" ? "#070710" : "#f0ece366", padding: "4px 9px", borderRadius: 15, cursor: "pointer", fontSize: 11, fontWeight: 700, fontFamily: "inherit" }}>EN</button>
          </div>
          <button onClick={() => setView("shop")} style={{ background: view === "shop" ? "#c8a96e22" : "transparent", border: "none", color: view === "shop" ? "#c8a96e" : "#f0ece355", padding: "8px 10px", borderRadius: 10, cursor: "pointer", fontSize: 14, fontFamily: "inherit" }}>🏠</button>
          <button onClick={() => setView("cart")} style={{ background: view === "cart" ? "#c8a96e22" : "transparent", border: "none", color: view === "cart" ? "#c8a96e" : "#f0ece355", padding: "8px 10px", borderRadius: 10, cursor: "pointer", fontSize: 14, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 3 }}>
            🛒{cartCnt > 0 && <span style={{ background: "#e05252", color: "#fff", borderRadius: "50%", width: 18, height: 18, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800 }}>{cartCnt}</span>}
          </button>
          <button onClick={() => setShowAdmin(true)} title="Admin" style={{ background: "transparent", border: "none", color: "#f0ece322", padding: "8px 9px", borderRadius: 10, cursor: "pointer", fontSize: 13 }}>⚙️</button>
        </div>
      </nav>

      <div style={{ maxWidth: 720, margin: "0 auto", padding: "0 14px" }}>

        {/* ── SHOP ── */}
        {view === "shop" && <>
          <div style={{ marginTop: 16 }}>
            <FIFASection lang={lang} channels={channels} />
          </div>

          {/* Slider */}
          <div style={{ margin: "12px 0", borderRadius: 18, overflow: "hidden", position: "relative", height: 172, cursor: "pointer" }} onClick={() => setSIdx(i => (i + 1) % SLIDES.length)}>
            <div key={sl.id} style={{ background: sl.bg, height: "100%", padding: "20px 20px", display: "flex", flexDirection: "column", justifyContent: "flex-end", position: "relative", overflow: "hidden" }}>
              <div style={{ position: "absolute", top: -10, right: 14, fontSize: 100, opacity: .1, transform: "rotate(-10deg)", pointerEvents: "none", userSelect: "none" }}>{sl.e}</div>
              <div style={{ background: `${sl.ac}22`, display: "inline-block", padding: "3px 11px", borderRadius: 20, fontSize: 11, fontWeight: 700, color: sl.ac, marginBottom: 7, border: `1px solid ${sl.ac}44`, width: "fit-content" }}>{bn ? sl.bBn : sl.bEn} ✨</div>
              <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 20, fontWeight: 900, lineHeight: 1.2, marginBottom: 5 }}>{bn ? sl.tBn : sl.tEn}</div>
              <div style={{ fontSize: 13, opacity: .6 }}>{bn ? sl.sBn : sl.sEn}</div>
            </div>
            <div style={{ position: "absolute", bottom: 10, left: "50%", transform: "translateX(-50%)", display: "flex", gap: 6 }}>
              {SLIDES.map((_, i) => (
                <button key={i} onClick={e => { e.stopPropagation(); setSIdx(i); }} style={{ width: i === sIdx ? 20 : 7, height: 7, borderRadius: 50, border: "none", background: i === sIdx ? "#c8a96e" : "#ffffff44", cursor: "pointer", transition: "all .3s" }} />
              ))}
            </div>
          </div>

          <input placeholder={`🔍 ${bn ? "পণ্য খুঁজুন..." : "Search products..."}`} value={search} onChange={e => setSearch(e.target.value)} style={{ marginBottom: 13 }} />

          <div style={{ display: "flex", gap: 8, overflowX: "auto", marginBottom: 18, paddingBottom: 3 }}>
            {CATS.map(c => (
              <button key={c.id} className="pill" onClick={() => setCat(c.id)} style={{ background: cat === c.id ? "linear-gradient(135deg,#c8a96e,#e8c98e)" : "#11111e", color: cat === c.id ? "#070710" : "#f0ece3", border: cat === c.id ? "none" : "1px solid #22223a" }}>
                {c.ic} {bn ? c.bn : c.en}
              </button>
            ))}
          </div>

          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 900, marginBottom: 13, display: "flex", alignItems: "center", gap: 7 }}>
            {CATS.find(c => c.id === cat)?.ic} {bn ? CATS.find(c => c.id === cat)?.bn : CATS.find(c => c.id === cat)?.en}
            <span style={{ fontSize: 12, fontWeight: 400, opacity: .33, fontFamily: "inherit" }}>({filtered.length}{bn ? "টি পণ্য" : " products"})</span>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 13 }}>
            {filtered.map(p => {
              const disc = Math.round((1 - p.price / p.orig) * 100);
              const inC = cart.find(i => i.id === p.id);
              return (
                <div key={p.id} className="card" style={{ padding: 13 }}>
                  <div style={{ background: "#0a0a16", borderRadius: 11, height: 102, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 48, marginBottom: 10, position: "relative" }}>
                    {p.emoji}
                    <div style={{ position: "absolute", top: 6, right: 6, display: "flex", flexDirection: "column", gap: 3, alignItems: "flex-end" }}>
                      <span style={{ background: "linear-gradient(135deg,#c8a96e,#e8c98e)", color: "#070710", fontSize: 10, fontWeight: 800, padding: "2px 7px", borderRadius: 6 }}>-{disc}%</span>
                      {p.hot && <span style={{ background: "#e05252", color: "#fff", fontSize: 10, fontWeight: 800, padding: "2px 7px", borderRadius: 6 }}>HOT</span>}
                    </div>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 2, lineHeight: 1.3 }}>{bn ? p.nameBn : p.name}</div>
                  <div style={{ fontSize: 11, opacity: .38, marginBottom: 5 }}>{bn ? p.name : p.nameBn}</div>
                  <div style={{ color: "#c8a96e", fontSize: 12 }}>{"★".repeat(Math.floor(p.r))}{"☆".repeat(5 - Math.floor(p.r))} <span style={{ opacity: .35, fontSize: 11 }}>({p.rv})</span></div>
                  <div style={{ margin: "7px 0 8px", display: "flex", alignItems: "baseline", gap: 7 }}>
                    <span style={{ fontSize: 16, fontWeight: 900, color: "#c8a96e" }}>৳{p.price}</span>
                    <span style={{ fontSize: 11, opacity: .28, textDecoration: "line-through" }}>৳{p.orig}</span>
                  </div>
                  <div style={{ fontSize: 10, opacity: .28, marginBottom: 8 }}>{bn ? "স্টকঃ" : "Stock:"} {p.stk}{bn ? "টি" : ""}</div>
                  {inC ? (
                    <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 6 }}>
                      <button className="bg" onClick={() => updQty(p.id, -1)} style={{ width: 32, padding: "7px 0", flexShrink: 0 }}>−</button>
                      <span style={{ flex: 1, textAlign: "center", fontWeight: 800 }}>{inC.qty}</span>
                      <button className="bg" onClick={() => updQty(p.id, 1)} style={{ width: 32, padding: "7px 0", flexShrink: 0 }}>+</button>
                    </div>
                  ) : (
                    <button className="bg" onClick={() => addCart(p)} style={{ marginBottom: 6 }}>🛒 {bn ? "কার্টে যোগ করুন" : "Add to Cart"}</button>
                  )}
                  <button className="bo" onClick={() => buyNow(p)}>⚡ {bn ? "এখনই কিনুন" : "Buy Now"}</button>
                </div>
              );
            })}
          </div>
          {filtered.length === 0 && <div style={{ textAlign: "center", padding: "48px 0", opacity: .27 }}>{bn ? "কোনো পণ্য পাওয়া যায়নি 😔" : "No products found 😔"}</div>}

          <div style={{ background: "linear-gradient(135deg,#0a2e1a,#104028)", border: "1px solid #1e5c36", borderRadius: 15, padding: "14px 17px", marginTop: 20, display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 32 }}>🚚</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: 13, color: "#69f0ae" }}>{bn ? "ফ্রি ডেলিভারি!" : "Free Delivery!"}</div>
              <div style={{ fontSize: 12, opacity: .6, marginTop: 2 }}>{bn ? "১০০০ টাকার উপরে যেকোনো অর্ডারে বিনামূল্যে ডেলিভারি" : "Free delivery on orders above ৳1,000"}</div>
            </div>
          </div>
        </>}

        {/* ── CART ── */}
        {view === "cart" && <>
          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 20, fontWeight: 900, marginTop: 20, marginBottom: 15 }}>🛒 {bn ? "আপনার কার্ট" : "Your Cart"}</div>
          {cart.length === 0 ? (
            <div style={{ textAlign: "center", padding: "58px 0" }}>
              <div style={{ fontSize: 68, marginBottom: 12 }}>🛒</div>
              <div style={{ opacity: .33, marginBottom: 18 }}>{bn ? "কার্ট এখন খালি" : "Cart is empty"}</div>
              <button className="bg" style={{ width: "auto", padding: "11px 30px" }} onClick={() => setView("shop")}>{bn ? "শপিং শুরু করুন" : "Start Shopping"}</button>
            </div>
          ) : <>
            {cart.map(item => (
              <div key={item.id} className="card" style={{ padding: 13, marginBottom: 10, display: "flex", gap: 10, alignItems: "center" }}>
                <div style={{ fontSize: 30, background: "#0a0a16", borderRadius: 8, padding: "7px 10px", flexShrink: 0 }}>{item.emoji}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{bn ? item.nameBn : item.name}</div>
                  <div style={{ fontSize: 11, opacity: .35 }}>{bn ? item.name : item.nameBn}</div>
                  <div style={{ color: "#c8a96e", fontWeight: 800, fontSize: 13, marginTop: 3 }}>৳{item.price}×{item.qty}=৳{item.price * item.qty}</div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 5, alignItems: "center", flexShrink: 0 }}>
                  <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
                    <button className="bg" onClick={() => updQty(item.id, -1)} style={{ width: 27, height: 27, padding: 0, borderRadius: 7, fontSize: 15 }}>−</button>
                    <span style={{ fontWeight: 800, minWidth: 18, textAlign: "center" }}>{item.qty}</span>
                    <button className="bg" onClick={() => updQty(item.id, 1)} style={{ width: 27, height: 27, padding: 0, borderRadius: 7, fontSize: 15 }}>+</button>
                  </div>
                  <button onClick={() => remCart(item.id)} style={{ background: "none", border: "none", color: "#e05252", cursor: "pointer", fontSize: 11 }}>🗑️ {bn ? "সরান" : "Remove"}</button>
                </div>
              </div>
            ))}
            <div className="card" style={{ padding: 17, marginTop: 6 }}>
              <div style={{ fontWeight: 700, marginBottom: 11, fontSize: 14 }}>📊 {bn ? "অর্ডার সারসংক্ষেপ" : "Order Summary"}</div>
              <div className="ir"><span style={{ opacity: .55 }}>{bn ? "পণ্যের মোট" : "Products Total"}</span><span>৳{cartSub}</span></div>
              <div className="ir">
                <span style={{ opacity: .55 }}>{bn ? "ডেলিভারি চার্জ" : "Delivery"}</span>
                <span style={{ color: cartSub >= 1000 ? "#69f0ae" : "#f0ece3" }}>{cartSub >= 1000 ? (bn ? "ফ্রি 🎉" : "Free 🎉") : (bn ? "ঢাকাঃ ৳৭০ / বাইরেঃ ৳১২০" : "Dhaka: ৳70 / Outside: ৳120")}</span>
              </div>
              {cartSub < 1000 && <div style={{ fontSize: 11, opacity: .27, padding: "3px 0" }}>{bn ? "১০০০+ টাকায় ফ্রি ডেলিভারি" : "Free delivery above ৳1,000"}</div>}
              <div style={{ borderTop: "1px solid #22223a", paddingTop: 10, marginTop: 4, display: "flex", justifyContent: "space-between", fontWeight: 900, fontSize: 16 }}>
                <span>{bn ? "মোট" : "Total"}</span>
                <span style={{ color: "#c8a96e" }}>{cartSub >= 1000 ? `৳${cartSub}` : `৳${cartSub} ${bn ? "+ ডেলিভারি" : "+ Delivery"}`}</span>
              </div>
              <button className="bg" style={{ marginTop: 13, padding: 12, fontSize: 14 }} onClick={() => setView("checkout")}>{bn ? "চেকআউট করুন →" : "Checkout →"}</button>
              <button className="bgh" style={{ marginTop: 7 }} onClick={() => setView("shop")}>{bn ? "← শপিং চালিয়ে যান" : "← Continue Shopping"}</button>
            </div>
          </>}
        </>}

        {/* ── CHECKOUT ── */}
        {view === "checkout" && <>
          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 20, fontWeight: 900, marginTop: 20, marginBottom: 15 }}>📦 {bn ? "ডেলিভারি তথ্য" : "Delivery Details"}</div>
          <div className="card" style={{ padding: 17, marginBottom: 12 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 11 }}>
              <div>
                <label style={{ fontSize: 12, opacity: .45, marginBottom: 5, display: "block" }}>{bn ? "আপনার নাম *" : "Your Name *"}</label>
                <input placeholder={bn ? "পূর্ণ নাম লিখুন" : "Enter full name"} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
              </div>
              <div>
                <label style={{ fontSize: 12, opacity: .45, marginBottom: 5, display: "block" }}>{bn ? "মোবাইল নম্বর *" : "Mobile Number *"}</label>
                <input placeholder="01XXXXXXXXX" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
              </div>
              <div>
                <label style={{ fontSize: 12, opacity: .45, marginBottom: 7, display: "block" }}>{bn ? "ডেলিভারি এলাকা *" : "Delivery Area *"}</label>
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={() => setForm({ ...form, area: "dhaka" })} style={{ flex: 1, padding: "11px 0", borderRadius: 10, border: `2px solid ${form.area === "dhaka" ? "#c8a96e" : "#22223a"}`, background: form.area === "dhaka" ? "#c8a96e22" : "#11111e", color: form.area === "dhaka" ? "#c8a96e" : "#f0ece355", fontWeight: 700, cursor: "pointer", fontFamily: "inherit", fontSize: 12 }}>
                    🏙️ {bn ? "ঢাকার ভিতরে" : "Inside Dhaka"}<br />
                    <span style={{ fontSize: 10, fontWeight: 400 }}>{bn ? "চার্জ:" : "Charge:"} {cartSub >= 1000 ? (bn ? "ফ্রি" : "Free") : "৳৭০"}</span>
                  </button>
                  <button onClick={() => setForm({ ...form, area: "outside" })} style={{ flex: 1, padding: "11px 0", borderRadius: 10, border: `2px solid ${form.area === "outside" ? "#c8a96e" : "#22223a"}`, background: form.area === "outside" ? "#c8a96e22" : "#11111e", color: form.area === "outside" ? "#c8a96e" : "#f0ece355", fontWeight: 700, cursor: "pointer", fontFamily: "inherit", fontSize: 12 }}>
                    🗺️ {bn ? "ঢাকার বাইরে" : "Outside Dhaka"}<br />
                    <span style={{ fontSize: 10, fontWeight: 400 }}>{bn ? "চার্জ:" : "Charge:"} {cartSub >= 1000 ? (bn ? "ফ্রি" : "Free") : "৳১২০"}</span>
                  </button>
                </div>
                {cartSub >= 1000 && <div style={{ marginTop: 7, background: "#0a2e1a", border: "1px solid #1e5c36", borderRadius: 8, padding: "7px 11px", fontSize: 12, color: "#69f0ae" }}>{bn ? "🎉 ১০০০+ টাকা — ডেলিভারি সম্পূর্ণ ফ্রি!" : "🎉 ৳1,000+ order — Delivery is FREE!"}</div>}
              </div>
              <div>
                <label style={{ fontSize: 12, opacity: .45, marginBottom: 5, display: "block" }}>{bn ? "জেলা *" : "District *"}</label>
                <select value={form.district} onChange={e => setForm({ ...form, district: e.target.value })}>
                  <option value="">{bn ? "জেলা বেছে নিন" : "Select district"}</option>
                  {["ঢাকা","চট্টগ্রাম","রাজশাহী","খুলনা","সিলেট","বরিশাল","রংপুর","ময়মনসিংহ","কুমিল্লা","গাজীপুর","নারায়ণগঞ্জ","টাঙ্গাইল","বগুড়া","যশোর","পাবনা","নোয়াখালী","ফেনী","লক্ষ্মীপুর"].map(d => <option key={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 12, opacity: .45, marginBottom: 5, display: "block" }}>{bn ? "পূর্ণ ঠিকানা *" : "Full Address *"}</label>
                <input placeholder={bn ? "বাড়ি নম্বর, রোড, এলাকা" : "House no., Road, Area"} value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} />
              </div>
            </div>
          </div>
          <div className="card" style={{ padding: 15, marginBottom: 12 }}>
            <div style={{ fontWeight: 700, marginBottom: 9, fontSize: 13 }}>💳 {bn ? "পেমেন্ট পদ্ধতি" : "Payment Method"}</div>
            <div style={{ background: "#0a2e1a", borderRadius: 9, padding: 12, border: "1.5px solid #1e5c36" }}>
              <div style={{ fontWeight: 700, color: "#69f0ae" }}>🚪 {bn ? "ক্যাশ অন ডেলিভারি" : "Cash on Delivery"}</div>
              <div style={{ fontSize: 12, opacity: .5, marginTop: 4 }}>{bn ? "পণ্য পেয়ে টাকা দিন — সম্পূর্ণ নিরাপদ" : "Pay when you receive — 100% safe"}</div>
            </div>
          </div>
          <div className="card" style={{ padding: 15, marginBottom: 13 }}>
            {cart.map(i => <div className="ir" key={i.id} style={{ opacity: .6 }}><span style={{ fontSize: 12 }}>{bn ? i.nameBn : i.name} × {i.qty}</span><span>৳{i.price * i.qty}</span></div>)}
            <div className="ir">
              <span style={{ opacity: .5 }}>{bn ? "ডেলিভারি চার্জ" : "Delivery"}</span>
              <span style={{ color: delAmt === 0 ? "#69f0ae" : "#f0ece3" }}>{delAmt === 0 ? (bn ? "ফ্রি 🎉" : "Free 🎉") : `৳${delAmt}`}</span>
            </div>
            <div style={{ borderTop: "1px solid #22223a", paddingTop: 10, marginTop: 4, display: "flex", justifyContent: "space-between", fontWeight: 900, fontSize: 16 }}>
              <span>{bn ? "মোট পরিশোধ" : "Total Payable"}</span><span style={{ color: "#c8a96e" }}>৳{grand}</span>
            </div>
          </div>
          <button className="bg" style={{ padding: 14, fontSize: 14, marginBottom: 7 }} onClick={placeOrder}>{bn ? "✅ অর্ডার কনফার্ম করুন" : "✅ Confirm Order"}</button>
          <button className="bgh" onClick={() => setView("cart")}>{bn ? "← কার্টে ফিরুন" : "← Back to Cart"}</button>
        </>}

        {/* ── SUCCESS ── */}
        {view === "success" && order && <>
          <div style={{ textAlign: "center", padding: "26px 0 16px" }}>
            <div style={{ width: 84, height: 84, borderRadius: 50, background: "linear-gradient(135deg,#c8a96e,#e8c98e)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40, margin: "0 auto 16px", boxShadow: "0 0 40px #c8a96e66" }}>✅</div>
            <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 24, fontWeight: 900, color: "#c8a96e", marginBottom: 6 }}>{bn ? "অর্ডার সফল!" : "Order Successful!"}</div>
            <div style={{ opacity: .44, fontSize: 13, marginBottom: 4 }}>{bn ? "আপনার অর্ডার সফলভাবে গ্রহণ হয়েছে" : "Your order has been placed successfully"}</div>
            <div style={{ background: "#11111e", border: "1px solid #22223a", borderRadius: 9, padding: "6px 16px", display: "inline-block", marginTop: 6 }}>
              <span style={{ fontSize: 10, opacity: .36 }}>{bn ? "অর্ডার আইডিঃ " : "Order ID: "}</span>
              <span style={{ fontWeight: 800, color: "#c8a96e" }}>{order.oid}</span>
            </div>
          </div>
          <div className="card" style={{ padding: 17, marginBottom: 12 }}>
            <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 11, color: "#c8a96e" }}>🧾 {bn ? "অর্ডার বিস্তারিত" : "Order Details"}</div>
            {order.items.map(i => <div className="ir" key={i.id} style={{ fontSize: 12 }}><span style={{ opacity: .6 }}>{bn ? i.nameBn : i.name} × {i.qty}</span><span>৳{i.price * i.qty}</span></div>)}
            <div className="ir" style={{ fontSize: 12 }}>
              <span style={{ opacity: .5 }}>{bn ? "ডেলিভারি" : "Delivery"}</span>
              <span style={{ color: order.del === 0 ? "#69f0ae" : "#f0ece3" }}>{order.del === 0 ? (bn ? "ফ্রি 🎉" : "Free 🎉") : `৳${order.del}`}</span>
            </div>
            <div style={{ borderTop: "1px solid #22223a", paddingTop: 10, marginTop: 4, display: "flex", justifyContent: "space-between", fontWeight: 900, fontSize: 15 }}>
              <span>{bn ? "মোট পরিশোধ" : "Total Paid"}</span><span style={{ color: "#c8a96e" }}>৳{order.grand}</span>
            </div>
          </div>
          <div className="card" style={{ padding: 17, marginBottom: 12 }}>
            <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 11, color: "#c8a96e" }}>📍 {bn ? "ডেলিভারি তথ্য" : "Delivery Info"}</div>
            <div className="ir" style={{ fontSize: 12 }}><span style={{ opacity: .38 }}>{bn ? "নাম" : "Name"}</span><span style={{ fontWeight: 600 }}>{order.name}</span></div>
            <div className="ir" style={{ fontSize: 12 }}><span style={{ opacity: .38 }}>{bn ? "মোবাইল" : "Mobile"}</span><span style={{ fontWeight: 600 }}>{order.phone}</span></div>
            <div className="ir" style={{ fontSize: 12 }}><span style={{ opacity: .38 }}>{bn ? "জেলা" : "District"}</span><span style={{ fontWeight: 600 }}>{order.district}</span></div>
            <div className="ir" style={{ fontSize: 12 }}><span style={{ opacity: .38 }}>{bn ? "ঠিকানা" : "Address"}</span><span style={{ fontWeight: 600, textAlign: "right", maxWidth: "55%" }}>{order.address}</span></div>
            <div style={{ marginTop: 12, background: order.area === "dhaka" ? "#0a1a2e" : "#1a0a2e", border: `1px solid ${order.area === "dhaka" ? "#1e3a5c" : "#3a1e5c"}`, borderRadius: 11, padding: "12px 14px", display: "flex", gap: 10, alignItems: "center" }}>
              <span style={{ fontSize: 26 }}>⏱️</span>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13, color: order.area === "dhaka" ? "#4fc3f7" : "#ce93d8" }}>
                  {order.area === "dhaka" ? (bn ? "ঢাকার ভিতরে —" : "Inside Dhaka —") : (bn ? "ঢাকার বাইরে —" : "Outside Dhaka —")} {bn ? "আনু. ডেলিভারি" : "Est. Delivery"}
                </div>
                <div style={{ fontSize: 12, opacity: .6, marginTop: 3 }}>
                  {order.area === "dhaka" ? (bn ? "🗓️ ১–২ কার্যদিবস" : "🗓️ 1–2 business days") : (bn ? "🗓️ ৩–৪ কার্যদিবস" : "🗓️ 3–4 business days")}
                </div>
              </div>
            </div>
          </div>
          <div className="card" style={{ padding: 17, marginBottom: 12 }}>
            <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 5, color: "#c8a96e" }}>📞 {bn ? "যোগাযোগ করুন" : "Contact Us"}</div>
            <div style={{ fontSize: 12, opacity: .38, marginBottom: 12 }}>{bn ? "যেকোনো সমস্যায় WhatsApp করুন" : "Reach us on WhatsApp for any queries"}</div>
            <a href="https://wa.me/8801840128865" target="_blank" rel="noreferrer" style={{ textDecoration: "none" }}>
              <button className="wb">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" /></svg>
                WhatsApp: 01840128865
              </button>
            </a>
          </div>
          <button className="bg" style={{ padding: 13, fontSize: 14, marginBottom: 6 }} onClick={() => { setView("shop"); setForm({ name: "", phone: "", address: "", district: "", area: "dhaka" }); }}>{bn ? "🛍️ আবার কেনাকাটা করুন" : "🛍️ Shop Again"}</button>
        </>}

      </div>

      {/* FOOTER */}
      <footer style={{ background: "#0a0a18", borderTop: "1px solid #1e1e34", marginTop: 34, padding: "22px 18px 16px" }}>
        <div style={{ maxWidth: 720, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: "linear-gradient(135deg,#c8a96e,#e8c98e)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 900, color: "#070710", fontFamily: "serif" }}>N</div>
            <div>
              <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 15, fontWeight: 900, color: "#c8a96e" }}>NextGen Style BD</div>
              <div style={{ fontSize: 9, opacity: .28, letterSpacing: 2 }}>PREMIUM LIFESTYLE STORE</div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 13, marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#c8a96e", marginBottom: 6 }}>📦 {bn ? "ডেলিভারি" : "Delivery"}</div>
              <div style={{ fontSize: 11, opacity: .42, lineHeight: 1.9 }}>
                {bn ? "ঢাকা: ১-২ দিন (৳৭০)" : "Dhaka: 1-2 days (৳70)"}<br />
                {bn ? "সারাদেশ: ৩-৪ দিন (৳১২০)" : "Nationwide: 3-4 days (৳120)"}<br />
                {bn ? "১০০০+ টাকায় ফ্রি" : "Free above ৳1,000"}
              </div>
            </div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#c8a96e", marginBottom: 6 }}>💳 {bn ? "পেমেন্ট" : "Payment"}</div>
              <div style={{ fontSize: 11, opacity: .42, lineHeight: 1.9 }}>
                {bn ? "ক্যাশ অন ডেলিভারি" : "Cash on Delivery"}<br />
                bKash / Nagad<br />
                {bn ? "১০০% নিরাপদ" : "100% Safe"}
              </div>
            </div>
          </div>
          <div style={{ background: "#11111e", border: "1px solid #22223a", borderRadius: 10, padding: "10px 14px", display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, marginBottom: 2 }}>📞 {bn ? "সাপোর্ট" : "Support"}</div>
              <div style={{ fontSize: 13, color: "#25d366", fontWeight: 700 }}>01840128865</div>
            </div>
            <a href="https://wa.me/8801840128865" target="_blank" rel="noreferrer" style={{ textDecoration: "none" }}>
              <button style={{ background: "#25d366", border: "none", color: "#fff", borderRadius: 8, padding: "6px 12px", fontWeight: 700, cursor: "pointer", fontSize: 12, fontFamily: "inherit" }}>WhatsApp</button>
            </a>
          </div>
          <div style={{ borderTop: "1px solid #1e1e34", paddingTop: 12, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 6 }}>
            <div style={{ fontSize: 10, opacity: .2 }}>{bn ? "© 2025 NextGen Style BD. সর্বস্বত্ব সংরক্ষিত।" : "© 2025 NextGen Style BD. All rights reserved."}</div>
            <div style={{ display: "flex", gap: 12 }}>
              <span className="fl">Facebook</span>
              <span className="fl">Instagram</span>
              <span style={{ fontSize: 12, cursor: "pointer", color: "#f0ece311" }} onClick={() => setShowAdmin(true)}>⚙️</span>
            </div>
          </div>
        </div>
      </footer>

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
